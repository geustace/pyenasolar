# pyenasolar

This library was created to communicate with EnaSolar solar inverters within Home Assistant.
It is based on the pysma and pysaj components written by @kellerza and @fredericvl
